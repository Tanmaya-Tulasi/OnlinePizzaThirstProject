# OnlinePizzaWebShop
An online Pizza shop with reviews and handling order requests using ASP.NET MVC Core and Entity Framework Core. 

Link to the Website on Azure: http://onlinepizzawebapplication20180819071654.azurewebsites.net/ (Online)
