﻿
namespace OnlinePizzaWebApplication.Repositories
{
    public interface IAdminRepository
    {
        void SeedDatabase();
        void ClearDatabase();
    }
}
